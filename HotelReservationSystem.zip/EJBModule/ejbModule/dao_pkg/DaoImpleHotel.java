package dao_pkg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.h2.engine.Session;
import org.hibernate.hql.ast.tree.Statement;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

public class DaoImpleHotel extends HibernateDaoSupport implements DaoInfHotel{

	
	@Override
	public String saveuserdetails(UserProfile up) {
		// TODO Auto-generated method stub
		Serializable s=getHibernateTemplate().save(up);
		return s.toString();
		
	}


	}
	

