package ejb_pkg1;

import java.util.List;

import javax.ejb.Remote;

import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

@Remote
public interface CHotelStatelessRemote {
	public List<RoomInfo> checkroominejb(RoomAvail r);
	public String cancelbookinginejb(int bookingid,String checkout);
	public String userdetailsinejb(UserProfile up);
	public String savebookingdetailsinejb(BookingInfo b);


}
