package service_pkg_3;

import java.util.Date;
import java.util.List;

import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

public interface ServiceInfHotel3 {
	public List<RoomInfo> checkroom(RoomAvail r);
	public String cancelbooking(int bookingid,Date checkout);
	//public String userdetails(UserProfile up);
public String bookingdetails(BookingInfo b);
}
