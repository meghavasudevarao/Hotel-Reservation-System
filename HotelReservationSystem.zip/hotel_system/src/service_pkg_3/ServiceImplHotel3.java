package service_pkg_3;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dao_pkg.DaoImpleHotel;
import dao_pkg.DaoInfHotel;

import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

public class ServiceImplHotel3 implements ServiceInfHotel3{
private DaoInfHotel dinf;

	public DaoInfHotel getDinf() {
	return dinf;
}

public void setDinf(DaoInfHotel dinf) {
	this.dinf = dinf;
}

	@Override
	public List<RoomInfo> checkroom(RoomAvail r) {
		List<RoomInfo> l=dinf.checkindb(r);
		System.out.println("in service"+l);
		return l;
	}

	@Override
	public String cancelbooking(int bookingid,Date checkout) {
	
String b=dinf.cancelbookingindb(bookingid, checkout);
System.out.println("in servive b is "+b);
return b;
}

	/*@Override
	public String userdetails(UserProfile up) {
		// TODO Auto-generated method stub
		return dinf.saveuserdetails(up);
	}
*/
	@Override
	public String bookingdetails(BookingInfo b) {
		// TODO Auto-generated method stub
		return dinf.savebookingdetails(b);
		
		
	}
	
}