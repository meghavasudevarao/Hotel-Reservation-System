package entity_pkg;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class UserProfile implements Serializable {
	private String firstname;
	private String lastname;
	private String address1;
	private String address2;
	private String country;
	private String emailid;
	private String state;
	private String city;
	private int pincode;
	private int contactnumber;
	private Set<BookingInfo>setuserid=new HashSet<BookingInfo>(0);
public UserProfile(String firstname, String lastname, String address1,
			String address2, String country, String emailid, String state,
			String city, int pincode, int contactnumber,
			Set<BookingInfo> setuserid, int userid) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.address1 = address1;
		this.address2 = address2;
		this.country = country;
		this.emailid = emailid;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.contactnumber = contactnumber;
		this.setuserid = setuserid;
		this.userid = userid;
	}
public UserProfile(int userid)
{
	this.userid=userid;
}
public UserProfile(UserProfile userid)
{
	this.userid=userid.getUserid();
}


public Set<BookingInfo> getSetuserid() {
	return setuserid;
}
public void setSetuserid(Set<BookingInfo> setuserid) {
	this.setuserid = setuserid;
}

private int userid;
	
	public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public int getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(int contactnumber) {
		this.contactnumber = contactnumber;
	}
	public UserProfile(String firstname, String lastname, String address1,
			String address2, String country, String emailid, String state,
			String city, int pincode, int contactnumber) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.address1 = address1;
		this.address2 = address2;
		this.country = country;
		this.emailid = emailid;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.contactnumber = contactnumber;
		
	}
	public UserProfile() {
		super();
	}
	@Override
	public String toString() {
		return "UserProfile [firstname=" + firstname + ", lastname=" + lastname
				+ ", address1=" + address1 + ", address2=" + address2
				+ ", country=" + country + ", emailid=" + emailid + ", state="
				+ state + ", city=" + city + ", pincode=" + pincode
				+ ", contactnumber=" + contactnumber;
	}
	
	

}
