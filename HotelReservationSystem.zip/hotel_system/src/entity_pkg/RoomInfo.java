package entity_pkg;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;


public class RoomInfo implements Serializable{

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Roominfo [roomid=");
		builder.append(roomid);
		builder.append(", roomtype=");
		builder.append(roomtype);
		builder.append(", drykitchenette=");
		builder.append(drykitchenette);
		builder.append(", sofacumbed=");
		builder.append(sofacumbed);
		builder.append(", doublebed=");
		builder.append(doublebed);
		builder.append(", telephone=");
		builder.append(telephone);
		builder.append(", telivision=");
		builder.append(telivision);
		builder.append(", roomcharges=");
		builder.append(roomcharges);
		builder.append("]");
		return builder.toString();
	}




	private String roomid;
	private String roomtype ;
	private String drykitchenette;
	private String sofacumbed;
	private String doublebed;
	private String telephone;
	private String telivision;
	private double roomcharges;
	private Set<BookingInfo>setroomid=new HashSet<BookingInfo>(0);
	
	
	
	
	public RoomInfo(String roomid)
	{
		this.roomid=roomid;
	}
	public RoomInfo(RoomInfo room)
	{
		this.roomid=room.getRoomid();
	}
	
	public RoomInfo(String roomid, String roomtype, String drykitchenette,
			String sofacumbed, String doublebed, String telephone,
			String telivision, double roomcharges, Set<BookingInfo> setroomid) {
		super();
		this.roomid = roomid;
		this.roomtype = roomtype;
		this.drykitchenette = drykitchenette;
		this.sofacumbed = sofacumbed;
		this.doublebed = doublebed;
		this.telephone = telephone;
		this.telivision = telivision;
		this.roomcharges = roomcharges;
		this.setroomid = setroomid;
	}





	public Set<BookingInfo> getSetroomid() {
		return setroomid;
	}





	public void setSetroomid(Set<BookingInfo> setroomid) {
		this.setroomid = setroomid;
	}





	public RoomInfo(String roomid, String roomtype, String drykitchenette,
			String sofacumbed, String doublebed, String telephone,
			String telivision, double roomcharges) {
		super();
		this.roomid = roomid;
		this.roomtype = roomtype;
		this.drykitchenette = drykitchenette;
		this.sofacumbed = sofacumbed;
		this.doublebed = doublebed;
		this.telephone = telephone;
		this.telivision = telivision;
		this.roomcharges = roomcharges;
	}





	public String getRoomid() {
		return roomid;
	}





	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}





	public String getRoomtype() {
		return roomtype;
	}





	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}





	public String getDrykitchenette() {
		return drykitchenette;
	}





	public void setDrykitchenette(String drykitchenette) {
		this.drykitchenette = drykitchenette;
	}





	public String getSofacumbed() {
		return sofacumbed;
	}





	public void setSofacumbed(String sofacumbed) {
		this.sofacumbed = sofacumbed;
	}





	public String getDoublebed() {
		return doublebed;
	}





	public void setDoublebed(String doublebed) {
		this.doublebed = doublebed;
	}





	public String getTelephone() {
		return telephone;
	}





	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}





	public String getTelivision() {
		return telivision;
	}





	public void setTelivision(String telivision) {
		this.telivision = telivision;
	}





	public double getRoomcharges() {
		return roomcharges;
	}





	public void setRoomcharges(double roomcharges) {
		this.roomcharges = roomcharges;
	}





	public RoomInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
