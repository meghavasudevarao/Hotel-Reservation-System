package entity_pkg;

import java.io.Serializable;
import java.util.Date;



public class RoomAvail implements Serializable {
	@Override
	public String toString() {
		return "RoomAvail [Checkin=" + Checkin + ", Checkout=" + Checkout
				+ ", noofroom=" + noofroom + ", noofperson=" + noofperson + "]";
	}
	private Date  Checkin;
	private  Date Checkout;
	
	public RoomAvail(Date checkin, Date checkout, String noofroom,
			String noofperson) {
		super();
		Checkin = checkin;
		Checkout = checkout;
		this.noofroom = noofroom;
		this.noofperson = noofperson;
	}

	public Date getCheckout() {
		return Checkout;
	}
	public void setCheckout(Date checkout) {
		Checkout = checkout;
	}
	private String noofroom;
	private String noofperson;

	
	
	

	public Date getCheckin() {
		return Checkin;
	}
	public void setCheckin(Date checkin) {
		Checkin = checkin;
	}

	public String getNoofroom() {
		return noofroom;
	}

	public void setNoofroom(String noofroom) {
		this.noofroom = noofroom;
	}

	public RoomAvail() {
		super();
	}

	public String getNoofperson() {
		return noofperson;
	}

	public void setNoofperson(String noofperson) {
		this.noofperson = noofperson;
	}
	
	

}
