package entity_pkg;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class BookingInfo implements Serializable{
	
	
	
	/**
	 * 
	 */
//private UserProfile up;
//private RoomInfo ri;
private RoomInfo roomid;
	private int bookingid ;
	
	private UserProfile userid;

	private Date startingfrom;

	private Date till;
	private String status;
	private double roomcharges;
	public int getBookingid() {
		return bookingid;
	}
	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}
	public BookingInfo(RoomInfo roomid, UserProfile userid, Date startingfrom,
			Date till, String status, double roomcharges) {
		super();
		this.roomid = roomid;
		this.userid = userid;
		this.startingfrom = startingfrom;
		this.till = till;
		this.status = status;
		this.roomcharges = roomcharges;
	}
	public RoomInfo getRoomid() {
		return roomid;
	}
	public void setRoomid(RoomInfo roomid) {
		this.roomid = roomid;
	}
	public UserProfile getUserid() {
		return userid;
	}
	public void setUserid(UserProfile userid) {
		this.userid = userid;
	}
	public Date getStartingfrom() {
		return startingfrom;
	}
	public void setStartingfrom(Date startingfrom) {
		this.startingfrom = startingfrom;
	}
	public Date getTill() {
		return till;
	}
	public void setTill(Date till) {
		this.till = till;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getRoomcharges() {
		return roomcharges;
	}
	public void setRoomcharges(double roomcharges) {
		this.roomcharges = roomcharges;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BookinIinfo [bookingid=");
		builder.append(bookingid);
		builder.append(", roomid=");
		builder.append(roomid);
		builder.append(", userid=");
		builder.append(userid);
		builder.append(", startingfrom=");
		builder.append(startingfrom);
		builder.append(", till=");
		builder.append(till);
		builder.append(", status=");
		builder.append(status);
		builder.append(", roomcharges=");
		builder.append(roomcharges);
		builder.append("]");
		return builder.toString();
	}
	public BookingInfo(int bookingid, RoomInfo roomid, UserProfile userid,
			Date startingfrom, Date till, String status, double roomcharges) {
		super();
		this.bookingid = bookingid;
		this.roomid = roomid;
		this.userid = userid;
		this.startingfrom = startingfrom;
		this.till = till;
		this.status = status;
		this.roomcharges = roomcharges;
	}
	public BookingInfo()
	{
		
		super();
		// TODO Auto-generated constructor stub
	}
	
}
