package service_pkg;

import java.util.List;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import ejb_pkg1.CHotelStatelessRemote;
import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

public class ServiceImplHotel implements ServiceInfHotel{
	private InitialContext ic;
	private Object o;
	private CHotelStatelessRemote cr;
	
	
public ServiceImplHotel()
{
	
}

	
			
			


	@Override
	public String userdetails(UserProfile up) {
		// TODO Auto-generated method stub
		try {
			ic=new InitialContext();
			o=ic.lookup("hi");
			cr=(CHotelStatelessRemote) o;
			
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cr.userdetailsinejb(up);
	}

	@Override
	public String feedbackinejb(String feedback) {
		// TODO Auto-generated method stub
		InitialContext context;
		try {
			context = new InitialContext();

		    ConnectionFactory cf =
		      (ConnectionFactory)context.lookup("/ConnectionFactory");
		    Queue queue = (Queue)context.lookup("queue/twoq");
		    Connection connection;

				connection = cf.createConnection();
			
		    Session session = 
		      connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		    MessageProducer sender = session.createProducer(queue);
		    
		      String messageText = 
		        String.format("This is message number %s.", feedback);
		      TextMessage message = 
		        session.createTextMessage(messageText);
		      sender.send(message);
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Feedback sent successfully";
	}
}
	
	
