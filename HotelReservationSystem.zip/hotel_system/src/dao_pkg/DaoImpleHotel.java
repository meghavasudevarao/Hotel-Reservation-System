package dao_pkg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;

public class DaoImpleHotel extends HibernateDaoSupport implements DaoInfHotel{
	private Logger log;
	@Override
	public List<RoomInfo> checkindb(RoomAvail r) {
		List<RoomInfo> lrinfo=new ArrayList<RoomInfo>();
				List<RoomInfo> lrinfo1=new ArrayList<RoomInfo>();
				Date checkin=r.getCheckin();
				Date checkout =r.getCheckout();
				String bls="";
				List<String>roomid=new ArrayList<String>();
					System.out.println("jklsldslkj");
					List<BookingInfo> blist=getHibernateTemplate().find("from BookingInfo");
					for (BookingInfo bookingInfo : blist) {
						if (checkin.after(bookingInfo.getStartingfrom())&& checkin.before(bookingInfo.getTill()))
						{
							RoomInfo rinfo=new RoomInfo(bookingInfo.getRoomid());
							roomid.add(rinfo.getRoomid()
									);
							
						}
						else if (checkout.after(bookingInfo.getStartingfrom())&& checkout.before(bookingInfo.getTill()))
						{
							RoomInfo rinfo=new RoomInfo(bookingInfo.getRoomid());
							roomid.add(rinfo.getRoomid()
									);
							
						}	
						else if (bookingInfo.getStartingfrom().after(checkin)&& bookingInfo.getStartingfrom().before(checkout))
						{
							RoomInfo rinfo=new RoomInfo(bookingInfo.getRoomid());
							roomid.add(rinfo.getRoomid()
									);
							
						}
					}
					System.out.println(roomid);
					int i=roomid.size();
					String query="from RoomInfo ";
					if (i>0)
					{
					query = query +"where roomid not in (:roomid)";
						lrinfo=	getHibernateTemplate().findByNamedParam(query, "roomid", roomid);
					}
					else
						lrinfo=getHibernateTemplate().find(query);
					System.out.println(lrinfo);
					 return lrinfo;	
					
			}

	@Override
	public String cancelbookingindb(int bookingid,Date checkout) {
		
		
		String bls="";
		List<BookingInfo> lst=getHibernateTemplate().find("from BookingInfo where bookingid='"+bookingid+"'" );
			if (!lst.isEmpty())
		{
			BookingInfo binfo=lst.get(0);
			binfo.setTill(checkout);
			getHibernateTemplate().update(binfo);		
			bls=Integer.toString(bookingid);
		}
		System.out.println("in cancel "+bls);
		
		return bls;
	}
	
		

	@Override
	public  String savebookingdetails(BookingInfo b) {
		
	
		log=Logger.getLogger(getClass());
		log.info("in dao"+b);
		
	Serializable save = getHibernateTemplate().save(b);
		System.out.println(Integer.valueOf(save.toString()));
		return save.toString();

		
	}
	}
	

