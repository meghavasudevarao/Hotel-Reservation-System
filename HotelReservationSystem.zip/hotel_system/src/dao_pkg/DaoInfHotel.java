package dao_pkg;

import java.util.Date;
import java.util.List;

import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

public interface DaoInfHotel {
	public List<RoomInfo> checkindb(RoomAvail r);
	public String cancelbookingindb(int bookingid,Date checkout);
	public String savebookingdetails(BookingInfo b);
	
}
