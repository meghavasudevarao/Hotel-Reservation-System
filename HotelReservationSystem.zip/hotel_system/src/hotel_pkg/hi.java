/*package hotel_pkg;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import service_pkg.ServiceInfHotel;
import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;
@Controller
@SessionAttributes({"charges","sci","sco","snr","snp","sci1","sco1","snr1","snp1","rid"})
public class hi {
	@RequestMapping("/checkout")
	public ModelAndView get(@RequestParam("bookingid") int bookingid,
			@RequestParam("checkout") int checkout)
	{
		
		
		return new ModelAndView("postcheckout","","");
	}
			
	@RequestMapping("/postpayment")
	public ModelAndView get(@RequestParam("cardno") int cardno,
			@RequestParam("securitycode")int sc,
			@RequestParam("rname")String cardtype,@RequestParam("RoomCharges")double rc,
			@RequestParam("RoomId") String rid,
			@RequestParam("Checkin") String checkin,
			@RequestParam("Checkout")String checkout,
			@RequestParam("Nop")String nop,
	@RequestParam("Nor") String nor)
	{
		RoomInfo ri=new RoomInfo(rid, rc);
		BookingInfo b=new BookingInfo(rid, 132, checkin, checkout, "booked", rc);
		
		
		String pagename="postpayment";
		return new ModelAndView(pagename,"","");
	}
			@RequestMapping("/quickreservation")
			public ModelAndView get(@RequestParam("checkin") String checkin,@RequestParam("checkout") String checkout,
					@RequestParam("noofroom") int noofroom,@RequestParam("person") int noofperson)
			{
				ModelAndView mav=new ModelAndView("CustomerRegistration");
				mav.addObject("sci",checkin );
				mav.addObject("sco", checkout);
				mav.addObject("snr", noofroom);
				mav.addObject("snp", noofperson);
				return mav;
				
			}
			@RequestMapping("/cregistration")
	public ModelAndView get(@RequestParam("firstname")String firstname,
@RequestParam("lastname") String lastname,
@RequestParam("address1") String address1,
@RequestParam("address2") String address2,
@RequestParam("country") String country,
@RequestParam("emailid") String emailid,
@RequestParam("state") String state, 
@RequestParam("city") String city, 
@RequestParam("pincode") int pincode,
@RequestParam("contactnumber") int contactnumber)
	{
				ClassPathXmlApplicationContext c =
						new ClassPathXmlApplicationContext("beans.xml");
				Object o = c.getBean("obj1");
				ServiceInfHotel i =(ServiceInfHotel) o;
				
		System.out.println("in mv");
		UserProfile up=new UserProfile(firstname, lastname, address1,address2, country, emailid, state, city, pincode, contactnumber);
		i.userdetails(up);
		Map<String, Object> m=new java.util.HashMap<String, Object>();
	
		System.out.println(up);
		m.put("key",up);
		String pagename="Confirmation";
		return new  ModelAndView(pagename,"key2",m);
	}
	
	@RequestMapping("/payment")
	public ModelAndView get()
	{
		return new ModelAndView("payment");
	}
	
	
	
	@RequestMapping("/CustomerRegistration")
	public ModelAndView VCustomerRegistration(@RequestParam("RoomCharges") String rs,@RequestParam("RoomId") String rid )
	{
		ModelAndView mav=new ModelAndView("CustomerRegistration");
		mav.addObject("charges", rs);
		mav.addObject("rid", rid);
		
		return mav;
	}
	
	
	
			
	@RequestMapping("/checkbooking")
	
	public ModelAndView get(@RequestParam("checkin") String checkin,
			@RequestParam("checkout") String checkout,
			@RequestParam("noofroom") String nor,
			@RequestParam("person") String nop,@ModelAttribute("checkdetails")RoomAvail ra)
	{
		
		System.out.println("in model and view");
	
		ClassPathXmlApplicationContext c =
				new ClassPathXmlApplicationContext("beans.xml");
		Object o = c.getBean("obj1");
		ServiceInfHotel i =(ServiceInfHotel) o;
			
			RoomAvail r=new RoomAvail(checkin,checkout,nop,nor);
		System.out.println("in model"+r);
		List<RoomInfo> l=new ArrayList<RoomInfo>();
		//RoomAvail r=new RoomAvail("a","b", 1,2);
		System.out.println("r in model"+r);
		l=i.checkroom(r);
		Map<String, Object> m=new HashMap<String, Object>();
		m.put("room", l);
		System.out.println("list is"+l);
		ModelAndView mv=new ModelAndView();
		
		mv.addObject("check",l);
		
	    
		
		
			
		
		//mv.setViewName("Confirmation");
		
		Map<String, Object> m=new java.util.HashMap<String, Object>();
		m.put("check1", mv);
			
		if(!l.isEmpty())

			return new ModelAndView("ShowAvailability","key",l);
		
		else
					
		return new ModelAndView("index","key","rooms not available");
	
	
	}


	@RequestMapping("/checkingout")
	public ModelAndView get()
	{
		System.out.println("in model and view 2");
		ClassPathXmlApplicationContext c =
				new ClassPathXmlApplicationContext("beans.xml");
		Object o = c.getBean("obj1");
		ServiceInfHotel i = new ServiceImplHotel(); 		
			
		String bls=i.checkroom();
		String pagename="";
		if(bls=="rooms available")
	 pagename="checkout";
		else
			pagename="index";
		String value="fine classpath works";
		System.out.println(pagename);
	
		return new ModelAndView("","key","");
		
	}



*/