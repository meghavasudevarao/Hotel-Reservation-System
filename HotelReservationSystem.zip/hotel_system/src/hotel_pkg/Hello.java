package hotel_pkg;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import service_pkg.ServiceInfHotel;
import service_pkg_3.ServiceInfHotel3;
import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;
@Controller
@SessionAttributes({"charges","nor","nop","rid","cindate","coutdate","key","up"})
public class Hello {
	@RequestMapping("/earlycheckout")
	public ModelAndView earlycheckout()
	{
	return new ModelAndView("earlycheckout","","");
	}
	
	@RequestMapping("/checkout")
	public ModelAndView checkout(@RequestParam("bookingid") int bookingid,
			@RequestParam("checkout") Date checkout)
	{
		
		String bls="";
		ClassPathXmlApplicationContext c =
				new ClassPathXmlApplicationContext("beans.xml");
		Object o = c.getBean("obj2");
		ServiceInfHotel3 i =(ServiceInfHotel3) o;
		bls=i.cancelbooking(bookingid,checkout);
		System.out.println("hell"+bls);
		String id="";
		if(bls.equals(""))
		{
			System.out.println(bls.equals(""));
			return new ModelAndView("check","cancel","Invalid Booking Id");
		}
		else 
		{
			id="updated successfully and your booking id is"+bls;
		}
		return new ModelAndView("check","cancel",id);
	}
			
	@RequestMapping("/postpayemt")
	public ModelAndView payment(@ModelAttribute("cindate") Date checkin,
			@ModelAttribute("coutdate") Date checkout,
			@ModelAttribute("nop") String nop,
			@ModelAttribute("nor") String nor,
			@ModelAttribute("charges") double rc,
			@ModelAttribute("rid") String rid,@ModelAttribute("up") int userid)
	{
		System.out.println("in post payment");
		RoomInfo rid1=new RoomInfo(rid);
		UserProfile pf = new UserProfile(userid);
		BookingInfo b=new BookingInfo(rid1, pf, checkin, checkout, "booked", rc);
		ClassPathXmlApplicationContext c =
				new ClassPathXmlApplicationContext("beans.xml");
		Object o = c.getBean("obj2");
		ServiceInfHotel3 i =(ServiceInfHotel3) o;
		String a=i.bookingdetails(b);
		String pagename="postpayment";
			return new ModelAndView(pagename,"booking",a);
	}
			
			@RequestMapping("/cregistration")
	public ModelAndView cRegister(@RequestParam("firstname")String firstname,
@RequestParam("lastname") String lastname,
@RequestParam("address1") String address1,
@RequestParam("address2") String address2,
@RequestParam("country") String country,
@RequestParam("emailid") String emailid,
@RequestParam("state") String state, 
@RequestParam("city") String city, 
@RequestParam("pincode") int pincode,
@RequestParam("contactnumber") int contactnumber)
	{
				ClassPathXmlApplicationContext c =
						new ClassPathXmlApplicationContext("beans.xml");
				Object o = c.getBean("obj1");
				ServiceInfHotel i =(ServiceInfHotel) o;
				
		System.out.println("in mv");
		UserProfile up=new UserProfile(firstname, lastname, address1,address2, country, emailid, state, city, pincode, contactnumber);
		String a=i.userdetails(up);
		ModelAndView mav=new ModelAndView("Confirmation");
		int a1=Integer.parseInt(a);
		mav.addObject("up",a1);
		mav.addObject("key",up);
		return mav;
		
	}
	
	@RequestMapping("/confirm")
	public ModelAndView confirm()
	{
		return new ModelAndView("payment");
	}
	
	
	
	@RequestMapping("/booknow")
	public ModelAndView booknow(@RequestParam("RoomCharges") double rs,@RequestParam("RoomId") String rid
			)
	{
		ModelAndView mav=new ModelAndView("CustomerRegistration");
		mav.addObject("charges", rs);
		mav.addObject("rid",rid);
		return mav;
	}
	
	
	@RequestMapping("/feedback")
	public ModelAndView get(@RequestParam("feed") String feedback,
			@RequestParam("emailid") String  emailid)
	{
		System.out.println("in mv "+feedback);
		ClassPathXmlApplicationContext c =
				new ClassPathXmlApplicationContext("beans.xml");
		Object o = c.getBean("obj1");
		ServiceInfHotel i =(ServiceInfHotel) o;
		String f=i.feedbackinejb(feedback);
		return new ModelAndView("feedback","feed",f);
	}
	
	
	
	@RequestMapping("/checkbooking")
	
	public ModelAndView roomavail(@RequestParam("checkin") Date checkin,
			@RequestParam("checkout") Date checkout,
			@RequestParam("noofroom") String nor,
			@RequestParam("person") String nop/*,@ModelAttribute("checkdetails")RoomAvail ra*/)
	{
		
		System.out.println("in model and view"+checkin);
	
		ClassPathXmlApplicationContext c =
				new ClassPathXmlApplicationContext("beans.xml");
		Object o = c.getBean("obj2");
		ServiceInfHotel3 i =(ServiceInfHotel3) o;
			
			RoomAvail r=new RoomAvail(checkin,checkout,nop,nor);
		System.out.println("in model"+r);
		List<RoomInfo> l=new ArrayList<RoomInfo>();
		//RoomAvail r=new RoomAvail("a","b", 1,2);
		System.out.println("r in model"+r);
		l=i.checkroom(r);
	
		System.out.println("list is"+l);
	
		ModelAndView mav1=new ModelAndView("ShowAvailability");
		mav1.addObject("cindate",checkin );
		mav1.addObject("coutdate",checkout );
		mav1.addObject("nor",nor );
		mav1.addObject("nop",nop );
		mav1.addObject("key",l);
		
		
		
		if(!l.isEmpty())
				
			return mav1;
		
		else
					
		return new ModelAndView("index","rooms","rooms not available");
	
	
	}


	
	}




