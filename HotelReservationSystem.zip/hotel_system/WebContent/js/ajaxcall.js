function disblPrev(){
	
	
	document.getElementById("b1").disabled = true;
	makeAjaxCall();
	
}

function disblParticulr(){
	document.getElementById("b2").disabled = true;
	makeAjaxCall();
	
}
function makeAjaxCall() {
	
	
	var x = $("#lt").val();
	var y = $("#sd").val();
	var z = $("#lo").val();
	var s1 = $("#s1").val();
	var uid=$("#uid").html();

	if(y==""||y==null){
		 	
		   	y =getdays();
		    alert(y.toString());
	}else if(y.length>0){
		y=1;
		alert(y.toString());
	}
	 if($("#s1").val()=="Select Any")
	{
		$("#p1").html("you must select a day");
	}
	
	else
		{
	var url = "checking.actsdac";
	var params = "lt="+ x
	+ "&sd=" + y+ "&lo=" + z+ "&s1=" + s1+ "&uid=" +uid;
	alert(url+"?"+params);
	$.ajax({ url: url,
			data: params,
           	success: scrap,
	  		dataType: "json",
	    	error:function(){ alert("not ok");} });
		}
}
function scrap(z) {
	//alert(z.status);
	if (z.status==1)
	{		$("#p1").html("");
			$("#p2").html("Details saved successfully");
		}
	else if(z.status==2)
		{
			$("#p2").html("");
			$("#p1").html("Already Submitted");
		}		
}