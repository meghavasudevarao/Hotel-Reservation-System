package msg_pkg;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 * Message-Driven Bean implementation class for: CMessageDrivenBean
 *
 */

@MessageDriven(activationConfig =
{
  @ActivationConfigProperty(propertyName="destinationType", 
                            propertyValue="javax.jms.Queue"),
  @ActivationConfigProperty(propertyName="destination", 
                            propertyValue="queue/twoq")
})
public class CMessageDrivenBean implements MessageListener {

    /**
     * Default constructor. 
     */
    public CMessageDrivenBean() {
        // TODO Auto-generated constructor stub
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    public void onMessage(Message message) {
        // TODO Auto-generated method stub
    	 TextMessage txtMsg = (TextMessage)message;    
    	    try {
    	      String msg = txtMsg.getText();
    	      System.out.printf("Received message: %s", msg);
    	    } catch (JMSException e) {
    	      e.printStackTrace();
    	    }
    	  }    

}
