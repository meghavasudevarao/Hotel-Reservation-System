package service_pkg_3;

import java.util.List;

import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

public interface ServiceInfHotel {
	public List<RoomInfo> checkroom(RoomAvail r);
	public String cancelbooking(int bookingid);
	public void userdetails(UserProfile up);

}
