/*package hotel_pkg;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import service_pkg_3.ServiceInfHotel;
import entity_pkg.RoomAvail;
import entity_pkg.UserProfile;

public class Chotel {
public static void main(String[] args) {
	


		ClassPathXmlApplicationContext c =
				new ClassPathXmlApplicationContext("beans.xml");
		Object o = c.getBean("obj1");
		ServiceInfHotel i =(ServiceInfHotel) o;
		RoomAvail r=new RoomAvail("2013-07-13", "2013-07-15", "1", "1");
		UserProfile up=new UserProfile("indu", "singh", "120 hargobind", "anand vihar", "india", "indu@gmail.com", "delhi", "delhi", 100001, 98765544);
		 i.checkroom(r);
		 i.userdetails(up);
		 
		
			
		
		
		
	}
	

}
*/