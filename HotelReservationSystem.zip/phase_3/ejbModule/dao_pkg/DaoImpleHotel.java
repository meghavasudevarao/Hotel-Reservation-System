package dao_pkg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.h2.engine.Session;
import org.hibernate.hql.ast.tree.Statement;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

public class DaoImpleHotel extends HibernateDaoSupport implements DaoInfHotel{

	/*@Override
	public List<RoomInfo> checkindb(RoomAvail r) {
	List<RoomInfo>l=new ArrayList<RoomInfo>();
		
		System.out.println("in service"+r);
		int a=(int)(Math.random()*100);
		System.out.println(a);
				if(a%2==0)
		{
			RoomInfo r1=new RoomInfo("r1", "SingleBedRoomApartment", 100, true, true, true, true, true);
			l.add(r1);
			
			RoomInfo r2=new RoomInfo("r2", "TwinRoomApartemnt", 200, true, true, true, true, true);
			l.add(r2);
			RoomInfo r3=new RoomInfo("r3", "DoubleBedRoomApartment", 300, false, true, true, true, true);
			l.add(r3);
		}
			
		
		return l;
		
		
		//System.out.println("in dao"+r.getNoofperson());
		List<RoomInfo> lrinfo=new ArrayList<RoomInfo>();
		List<RoomInfo> lrinfo1=new ArrayList<RoomInfo>();
		String checkin=r.getCheckin();
		String checkout =r.getCheckout();
		//int a=(int)(Math.random()*100);
		//System.out.println(a);
		String bls="";
		
			System.out.println("jklsldslkj");
		//	lrinfo=getHibernateTemplate().find("from RoomInfo");
		lrinfo=getHibernateTemplate().find("from RoomInfo as d where d.roomid not in (select d.roomid from RoomInfo as d, BookingInfo as f where d.roomid=f.roomid and f.status='booked' and (f.startingfrom<='"+checkin+"' or f.till>='"+checkin+"' or f.startingfrom<='"+checkout+"' or f.till<='"+checkout+"')))");
		
		//	Roominfo account = new Roominfo("R005","SingleBedRoomApartmen","false","true","true","true", "true",600.0);
			//System.out.println(getHibernateTemplate());
			//getHibernateTemplate().save(account);
			Query q = session.createQuery("select * from Users u where u.username=:username");
			q.setString("username", username);
//System.out.println(getHibernateTemplate().find("select d.roomid from Roominfo as d, Bookinginfo as f where d.roomid=f.roomid and f.status='booked' and f.startingfrom<='2013-07-13' and f.startingfrom<='2013-07-13' and f.till>='2013-07-13' and f.startingfrom<='2013-07-19' and f.till<='2013-07-19'"));

for (Roominfo roominfo : lrinfo) {
getHibernateTemplate().initialize(roominfo);
lrinfo1.add(roominfo);
}
			
			//	"from Roominfo m,Bookinginfo j where m.roomid=j.roomid");
		


			
			//System.out.println(a);
			System.out.println(lrinfo);
			//System.out.println(lrinfo1);
			select * from bookingsinfo,roomsinfo where roomsinfo.RoomID=bookingsinfo.RoomID and BookingStatus='Booked' and bookingsinfo.From <='"+FromDate+"' 
					and bookingsinfo.To>='"+FromDate+"' and bookingsinfo.From <='"+ToDate+"' and bookingsinfo.To<='"+ToDate+"' and roomsinfo.RoomID='"+RoomID+"' ";
				 return lrinfo;	
			
	}

	@Override
	public String cancelbookingindb(int bookingid,String checkout) {
		System.out.println("in service");
		int a=(int)(Math.random()*100);
		System.out.println(a);
	
		if(a%2==0)
			{
			bls="booking id is valid";
			}
		else 
			bls="booking id is invalid";
		return bls;
		String bls="";
		List<BookingInfo> blst=getHibernateTemplate().find("from BookingInfo where bookingid='"+bookingid+"'");
		System.out.println(blst);
		if(!blst.isEmpty())
		{
			BookingInfo b1=blst.get(0);
			b1.setTill(checkout);
			getHibernateTemplate().update(b1);
			bls=Integer.toString(bookingid);
		}
		
		return bls;
		}
*/
	@Override
	public String saveuserdetails(UserProfile up) {
		// TODO Auto-generated method stub
		Serializable s=getHibernateTemplate().save(up);
		return s.toString();
		
	}

/*	@Override
	public  String savebookingdetails(BookingInfo b) {
		
	//getHibernateTemplate().save(b);
     
System.out.println("in dao"+b);
	BookingInfo b1=new BookingInfo();
	
	//org.hibernate.Session s1=null;
	//s1.save(b);
	//s1.getIdentifier(b1);
	
	//int a=b1.getUserid();
	//System.out.println(a);
	//getHibernateTemplate().save(b);
	//getHibernateTemplate().find(queryString)
	
	Serializable save = getHibernateTemplate().save(b);
		System.out.println(Integer.valueOf(save.toString()));
		return save.toString();
	List<BookingInfo> id=getHibernateTemplate().find("from BookingInfo where userid=",b1);
	return id;
		
		
	}*/
	}
	

