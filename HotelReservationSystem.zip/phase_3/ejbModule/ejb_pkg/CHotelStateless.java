package ejb_pkg;

import java.util.List;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ejb.interceptor.SpringBeanAutowiringInterceptor;

import dao_pkg.DaoImpleHotel;
import dao_pkg.DaoInfHotel;

import ejb_pkg1.CHotelStatelessRemote;
import entity_pkg.BookingInfo;
import entity_pkg.RoomAvail;
import entity_pkg.RoomInfo;
import entity_pkg.UserProfile;

/**
 * Session Bean implementation class CHotelStateless
 */
@Stateless(mappedName = "hi")

public class CHotelStateless implements CHotelStatelessRemote {
private DaoInfHotel dao;
private ClassPathXmlApplicationContext c;
private Object o;

	public DaoInfHotel getDao() {
	return dao;
}

public void setDao(DaoInfHotel dao) {
	this.dao = dao;
}


	public CHotelStateless() {
        // TODO Auto-generated constructor stub
		System.out.println("in ejb");
		 
		
    }

	/*@Override
	public List<RoomInfo> checkroominejb(RoomAvail r)
	{
		c =new ClassPathXmlApplicationContext("beans.xml");
		 o = c.getBean("ok");
		 dao= (DaoImpleHotel) o;
		System.out.println("check room in ejb");
		return dao.checkindb(r);
		
	}

	@Override
	public String cancelbookinginejb(int bookingid,String checkout) {
		c =new ClassPathXmlApplicationContext("beans.xml");
		 o = c.getBean("ok");
		 dao= (DaoImpleHotel) o;
		System.out.println("cancel in ejb");
		return dao.cancelbookingindb(bookingid,checkout);
		
	}*/

	@Override
	public String userdetailsinejb(UserProfile up) {
		c =new ClassPathXmlApplicationContext("beans.xml");
		 o = c.getBean("ok");
		 dao= (DaoImpleHotel) o;
		System.out.println("userdetails in ejb");
		return dao.saveuserdetails(up);
	}

	/*@Override
	public String savebookingdetailsinejb(BookingInfo b) {
		c =new ClassPathXmlApplicationContext("beans.xml");
		 o = c.getBean("ok");
		 dao= (DaoImpleHotel) o;
		System.out.println("savebooking in ejb");
		return dao.savebookingdetails(b);
	}*/

}
